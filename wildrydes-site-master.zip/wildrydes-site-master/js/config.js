window._config = {
    cognito: {
        userPoolId: 'eu-west-1_JTi25cDVB',
        userPoolClientId: '5qi4adsulhj6c35qgngict3car',
        region: 'eu-west-1'
    },
    api: {
        invokeUrl: 'https://k2cdp5ols3.execute-api.eu-west-1.amazonaws.com/prod'
    }
};
