import boto3
import time
import urllib
import pymysql

DATABASE_HOST = 'lab3-db.crxpcyzinmjk.us-east-1.rds.amazonaws.com' #RDS Endpoint
DATABASE_USER = 'admin'
DATABASE_PASSWORD = 'pass1234'
DATABASE_NAME = 'lab' 
CREATE_TABLE = True
TABLE_NAME = 'product_sale_summary'
BUCKET_NAME='s3-csv-20220509'
RDS_COLUMN_HEADERS = "product_name, quantity, amount, revenue, file_name"


print("Getting Values from environment variable")
try:
    
    DYNAMO_TABLE_NAME = "S3-log-20220512"
except Exception as error:
    print("Exception occurred while getting environment variable")
    print(error)


def lambda_handler(event, context):
    for record in event['Records']:

        if record['eventSource'] != 'aws:s3':
            print('Trigger is not from s3. Skipping Processing')
            return

        print("Trigger initiated from lambda")
        start_time = time.strftime('%Y%m%d_%H%M%S')

        print("Getting bucket name and filename")
        bucket_name = record['s3']['bucket']['name']

        # Get key replacing %xx of url-encoded value by equivalent character
        file_name = urllib.parse.unquote_plus(record['s3']['object']['key'], encoding="utf-8")
        print(f"Trigger is due to file: {file_name} in bucket: {bucket_name}")

        try:
            print("Getting file content")
            sales_file_content, file_name = get_file_from_s3(bucket_name, file_name, with_delete=True)
        except Exception as e:
            end_time = time.strftime('%Y%m%d_%H%M%S')
            print('Error occurred while obtaining file content from s3.', e)
            error_message = f'Error reading file from s3. The error encountered is {str(e)}'
            

            dynamo_data = {'StartTime': start_time, 'EndTime': end_time, 'FileName': file_name, 'Status': 'Failure',
                           'FailureReason': str(e), 'ErrorPhase': 'Reading s3 content from the reprocess bucket'}

            print("Uploading error data in DynamoDB")
            upload_to_dynamo(DYNAMO_TABLE_NAME, dynamo_data)
            continue

        try:
            print(f"Aggregating data of file {file_name}")
            summarized_transaction, records_processed = summarize_transaction(sales_file_content,
                                                                                                    file_name)
            print(f"Data of file: {file_name} aggregated.")
            print("Inserting aggregated data to database")
            insert_to_rds(summarized_transaction)
            print("Data inserted into database")

        except Exception as e:
            end_time = time.strftime('%Y%m%d_%H%M%S')
            print(f'Error summarizing file: {file_name}.', e)
            upload_to_s3(sales_file_content, BUCKET_NAME, file_name)

            error_message = f'Error occurred while processing the file: {file_name}. ' \
                            f'Please check error file in Bucket: {BUCKET_NAME} with FileName: {file_name}.' \
                            f'\n\nThe error message encountered was {str(e)}'


            print("Uploading fail message in DynamoDB")
            upload_to_dynamo(DYNAMO_TABLE_NAME, dynamo_data)
            continue

        end_time = time.strftime('%Y%m%d_%H%M%S')
        print("Data Summarized Successfully")
        dynamo_data = {'StartTime': start_time, 'EndTime': end_time, 'FileName': file_name, 'Status': 'Success',
                       'RecordProcessed': records_processed}

        print("Uploading stat in DynamoDB")
        upload_to_dynamo(DYNAMO_TABLE_NAME, dynamo_data)
       
        print(f"File {file_name} aggregated successfully")

def delete_s3_file(bucket, key):
    try:
        s3_resource = boto3.resource('s3')
        s3_resource.Object(bucket, key).delete()
    except Exception as e:
        raise Exception(e)


def get_file_from_s3(bucket_name, file_name, with_delete=False):
    try:
        s3 = boto3.client("s3")
        file_from_s3 = s3.get_object(Bucket=bucket_name, Key=file_name)
        file_content = file_from_s3["Body"].read().decode('utf-8-sig')

        if with_delete:
            delete_s3_file(bucket_name, file_name)

        return file_content, file_name

    except Exception as e:
        raise Exception(e)


def upload_to_s3(file_content, bucket_name, file_name):
    try:
        s3_resource = boto3.resource('s3')
        object_handler = s3_resource.Object(bucket_name, file_name)
        object_handler.put(Body=bytes(file_content, encoding="utf-8"))
    except Exception as e:
        raise Exception(e)


def upload_to_dynamo(table_name, data_to_push):
    try:
        dynamodb_resource = boto3.resource('dynamodb')
        dynamodb_table = dynamodb_resource.Table(table_name)
        dynamodb_table.put_item(Item=data_to_push)
    except Exception as e:
        raise Exception(e)

def summarize_transaction(transaction_data, file_name):
    summary_data = {}
    record_count = 0
    transaction_items = transaction_data.strip().split('\n')
    for transaction in transaction_items:
        record_count = record_count + 1
        product_name, quantity, amount, revenue = transaction.split(',')
        if product_name in summary_data.keys():
            current_quantity, current_amount, current_revenue = summary_data.get(product_name)
            summary_data[product_name] = current_quantity + int(quantity), current_amount + float(amount), \
                                         current_revenue + float(revenue)
        else:
            summary_data[product_name] = int(quantity), float(amount), float(revenue)

    # Store data as [('egg', 5, 100, 10, 'my_file'), ('apple', 1, 200, 20, 'my_file')]
    summary_list = [(key, *value, file_name) for key, value in summary_data.items()]

    return summary_list, record_count


def generate_sql_query(transaction_list):
    print("Generating SQL query")
    column_names = RDS_COLUMN_HEADERS
    data = str(transaction_list).strip('[]')
    sql_query = f'INSERT INTO {TABLE_NAME}({column_names}) VALUES {data};'
    return sql_query


def insert_to_rds(summarized_transaction):
    sql_query = generate_sql_query(summarized_transaction)
    print("Obtaining database connection")
    connection = pymysql.connect(host=DATABASE_HOST, user=DATABASE_USER, passwd=DATABASE_PASSWORD, db=DATABASE_NAME)

    with connection.cursor() as cursor:
        print("Executing SQL query")
        cursor.execute(sql_query)
    connection.commit()
